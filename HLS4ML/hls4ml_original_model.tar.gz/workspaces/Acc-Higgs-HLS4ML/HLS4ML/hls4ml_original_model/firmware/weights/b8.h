//Numpy array shape [1]
//Min 0.132273465395
//Max 0.132273465395
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
model_default_t b8[1];
#else
model_default_t b8[1] = {0.1322734654};
#endif

#endif
